//import { Mail, Home } from 'react-feather'
import pages from './pages'
import AppRoutes from './apps'

export default [...AppRoutes]
