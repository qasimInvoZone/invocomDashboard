import pages from './pages'
import AppRoutes from './apps'

export default [...pages]
