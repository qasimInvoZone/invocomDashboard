import {useState, useEffect, useContext} from 'react'
import MeetingHeadCards from './components/cards/MeetinHeadCards'
import MeetTable from './components/TablesAndForms/MeetingTable'
import CardMeetup from './components/cards/CardMeetup'
import CalenderComplete from './components/charts/MeetCompHeader'
import MeetCardSwiper from './components/Swiper/MeetCardSwiper'
import axios from 'axios'
//import { SocketContext } from '../service/socket' 
const Meeting = () => {

  //const socket = useContext(SocketContext);
  const [meetingData, setMeetingData] = useState({});
  //const [onlineUsers, setOnlineUser] = useState(0)

  // useEffect(() => {
  //   socket.emit('getConnectedUsers');

  //   socket.on('returnConnectedUsers', (data) => {
  //     setOnlineUser(data);
  //   })

  //   socket.on('connectedUsers', (data) => {
  //     setOnlineUser(data)
  //   })

  // }, [socket, setOnlineUser])
  //fetch token from localStorage
  useEffect(() => {
    const fetchMeetings = async () => {
      const baseUrl = 'http://stormy-sierra-19463.herokuapp.com'
      const apiVersion = 'api/v1'
      const entity = 'meeting'
      const endPoint = `${baseUrl}/${apiVersion}/${entity}/`
      const token = localStorage.getItem('token');
      try {
        const response = await axios.get(endPoint,
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        })
        console.log("lead", response.data);
        setMeetingData(response.data);
      } catch (e) {
        console.log("in dashboard catch");
        if (e && e?.response && e?.response?.status === 400) {
          console.log(e.response.data)
        }
      }
    }
    fetchMeetings()
  }, [axios, setMeetingData])
  console.log("meeting data : ",meetingData);
  return (
    <div className="p-2 bg-white mt-1" >
    
    <h2 className='m-2'><strong>Meeting Overview</strong></h2>
    
     <div className='mt-2'>
        <MeetingHeadCards meetingData={{
          totalMeetings: meetingData?.data?.totalMeetings,
          attendedMeetings: meetingData?.data?.attendedMeetings,
          unAttendedMeetings: meetingData?.data?.unAttendedMeetings,
          cancelledMeetings: meetingData?.data?.cancelledMeetings}}/>
     </div>   
    <div className="meet_card_head"> 
     <h2 className='m-2'> <strong>Meeting Schedule</strong></h2>
     <div className="meet_card_head_right">
     <CalenderComplete />
     
     </div>
    </div>
    <MeetCardSwiper meetingCard = {meetingData?.data?.meetings}/>
    <MeetTable meetingList = {meetingData?.data?.meetings}/>
    </div>
  )
}

export default Meeting
