const SOCKET_URL = 'http://stormy-sierra-19463.herokuapp.com/'
export default SOCKET_URL;