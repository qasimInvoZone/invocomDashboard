const initialState = {
  chats: [],
  contacts: [],
  userProfile: {},
  selectedUser: {}
}

const chatReducer = (state = initialState, action) => {
  return state
}

export default chatReducer